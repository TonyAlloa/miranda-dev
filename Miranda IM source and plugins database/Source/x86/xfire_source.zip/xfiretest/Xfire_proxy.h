#ifndef _XFIRE_PROXY
#define _XFIRE_PROXY

#include "baseProtocol.h"

int initXfireProxy();

#endif