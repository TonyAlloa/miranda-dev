#include "baseProtocol.h"
#include "m_variables.h"

char* Varxfiregame(ARGUMENTSINFO *ai);
char* Varmyxfiregame(ARGUMENTSINFO *ai);
char* Varmyxfirevoice(ARGUMENTSINFO *ai);
char* Varxfireserverip(ARGUMENTSINFO *ai);
char* Varxfirevoice(ARGUMENTSINFO *ai);
char* Varxfirevoiceip(ARGUMENTSINFO *ai);
char* Varmyxfirevoiceip(ARGUMENTSINFO *ai);
char* Varmyxfireserverip(ARGUMENTSINFO *ai);