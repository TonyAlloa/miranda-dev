//iniupdater.h  by dufte

#define INI_UPDATERHOST "xfireplus.com"
#define INI_REQUEST "/xfire_games/xfire_games.php?format=miranda"


//#define INI_URLREQUEST "http://xfireplus.com/xfire_games/xfire_games.php?format=miranda"
#define INI_URLREQUEST "http://xfire.pro-laming.de/getini.php?fsize="
#define INI_WHATSNEW "http://xfire.pro-laming.de/whatsnew.txt"
#define ICO_URLREQUEST "http://xfire.pro-laming.de/getini.php?mode=ico&fsize="