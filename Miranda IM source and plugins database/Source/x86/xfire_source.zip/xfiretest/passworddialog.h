#include "baseProtocol.h"
#include "resource.h"

void ShowPasswordDialog(char*pw,char*mynick=NULL);