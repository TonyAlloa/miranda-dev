//definitionen f�r die statusmsg handling geschichte
#include "baseProtocol.h"

//sichert die statusmeldungen in den speicher
BOOL BackupStatusMsg();
BOOL SetGameStatusMsg();
BOOL SetOldStatusMsg();