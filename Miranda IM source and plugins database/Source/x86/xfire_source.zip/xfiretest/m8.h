#ifndef _M8_H
#define _M8_H

#include "baseProtocol.h"

class Xfire_m8 : public PROTO_INTERFACE {
};

#endif