#include "baseProtocol.h"
#include "resource.h"

BOOL ShowSetNick();